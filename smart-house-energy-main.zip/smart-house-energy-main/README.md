# Single Page Application

This is a project demo that uses Vanilla JS to build a Single Page Application.